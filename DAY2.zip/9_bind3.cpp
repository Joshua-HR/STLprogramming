#include <iostream>
#include <algorithm>
#include <functional>


int main()
{
    int x[5] = { 9, 9,2,4,3};

    // 3의 배수가 아닌 것을 찾고 싶다.!

    auto p = std::find_if ( x, x+5, ? ); //
}

















//












//
