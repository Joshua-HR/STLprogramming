#include <iostream>

void foo(int& a) { a = 200; }

template<typename F, typename T> 
void forward_by_value(F f, T arg)
{
	f(arg);
}
int main()
{
	int n = 10;

	foo(n);	

	std::cout << n << std::endl; 
}
