#include <iostream>
#include <vector>
#include <list>
#include <functional>
#include <algorithm> 
#include <numeric>	 
#include "show.h"

int main()
{
	std::vector<int> v1 = { 1,2,3,4,5,6,7,8,9,10 };
	std::vector<int> v2;

	std::partial_sum(v1.begin(), v1.end(), std::back_inserter(v2));
	show(v2);
}